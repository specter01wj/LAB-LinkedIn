/*
 * This program asks the user for the heights of each student in class. 
 * Then finds the height of the tallest student, and the average height of all 
 * students.
 */
package heights;

/**
 *
 * @author Peggy Fisher
 */
public class Heights {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }
    
}
