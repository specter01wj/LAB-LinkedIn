/*
 * This program has a 2-D array to represent prices and discounts
 */
package prices;

/**
 *
 * @author Peggy Fisher
 */
public class Prices {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }
    
}
