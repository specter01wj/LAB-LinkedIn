/*
 * This program is used to demonstrate ArrayLists using the Property class
 * as the source of a our objects
 */
package realestatemls;

/**
 *
 * @author Peggy Fisher
 */
public class RealEstateMLS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
