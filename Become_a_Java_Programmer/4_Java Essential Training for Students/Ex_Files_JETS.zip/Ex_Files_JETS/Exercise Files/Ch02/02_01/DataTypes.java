/*
 * Basics Review
 */
 package basicsreview;
 /**
  *
  * @author Peggy Fisher 
 */
 public class DataTypes {
    public static void main(String() args) {
	    //Sample variables
		char letter = 'A';
		boolean done = false;
		int radius = 10;
		byte red = 127;
		short age = 21;
		long population = 313459000;
		float price = 10.59f;
		double circleArea = Math.PI*radius*radius;
		/*
		* Strings are actually arrays of characters
		*/
		String name = "Peggy Fisher";
		
	}
}
 