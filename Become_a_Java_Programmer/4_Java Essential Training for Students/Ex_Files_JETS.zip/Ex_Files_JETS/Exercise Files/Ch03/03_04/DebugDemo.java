public class DebugDemo {
	public static void main(String[] args) 
	{
        String message = args[0];
		System.out.println(message);
	}
}
	