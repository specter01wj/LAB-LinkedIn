
package arrayexamples;
/**
 *
 * @author Peggy Fisher
 */
public class ArrayExamples {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[] ages = new int[20];
        double[] prices = {5.25, 6.50, 2.30, 10.75};
        //prices array has a length of 4
        double total = prices[0] + 
                       prices[1] + 
                       prices[2] + 
                       prices[3]; 
        //responses array has a length of 5        
        boolean[] responses = {true, false, false, true, true};
        char[] vowels = {'a', 'e', 'i', 'o', 'u'};
        String[] names = new String[10];
        
        
    }
    
}
