//: [Previous](@previous)

import Foundation

var str = "Hello, playground"

