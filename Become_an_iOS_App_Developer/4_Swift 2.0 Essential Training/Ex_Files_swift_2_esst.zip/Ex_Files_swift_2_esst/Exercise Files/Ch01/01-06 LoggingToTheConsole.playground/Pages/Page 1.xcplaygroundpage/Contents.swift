//: ## Logging to the Console

import UIKit

var str = "Hello, playground"

var hello = "Hello,"; var playground = "playground"


//: [Next](@next)
