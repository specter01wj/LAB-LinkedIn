//: [Previous](@previous)

//: ### Literal Expressions

func printLiteralExpressions() {
  
  print("Function: \(__FUNCTION__)")
  print("File: \(__FILE__)")
  print("Line: \(__LINE__)")
  print("Column: \(__COLUMN__)")
  
}

