//: [Previous](@previous)

//: ### Delimiters

//: Single-line delimiter

/*: Text on this line not displayed in rendered markup
Block delimiter

## Header 2
### Header 3

> "Block quote"

* Milk
* Bread
* Bananas

----

1. Learn Swift
2. Develop an awesome app
3. Retire

print("Hello, world!")
*/

//: [Next](@next)
