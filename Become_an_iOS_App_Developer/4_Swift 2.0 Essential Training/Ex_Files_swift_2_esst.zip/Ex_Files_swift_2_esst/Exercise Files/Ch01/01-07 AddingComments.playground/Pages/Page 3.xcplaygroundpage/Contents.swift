//: [Previous](@previous)

//: ### Links & Images

//: [Swift blog](https://developer.apple.com/swift/)

//: ![Swift logo](https://developer.apple.com/assets/elements/icons/128x128/swift.png "The Swift logo")

//: ![Betty](Betty.png "Betty")

//: [Next](@next)
