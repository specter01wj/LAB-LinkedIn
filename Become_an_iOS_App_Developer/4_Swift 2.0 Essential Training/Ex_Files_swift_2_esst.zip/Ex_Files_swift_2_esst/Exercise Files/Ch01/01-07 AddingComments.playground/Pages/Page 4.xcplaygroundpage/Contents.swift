//: [Previous](@previous)

//: ### Quick Help Comments

/// A Quick Help comment
func someComplexFunction() { }

/**
Another Quick Help comment
- seealso: `someComplexFunction`
*/
func anotherComplexFunction() { }

