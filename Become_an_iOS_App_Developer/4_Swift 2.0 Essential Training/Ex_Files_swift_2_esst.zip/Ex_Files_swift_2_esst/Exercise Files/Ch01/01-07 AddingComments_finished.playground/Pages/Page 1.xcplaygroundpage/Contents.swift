//: ## Adding Comments

/*
// Single-line comment

var someVariable = "..."

func someFunction() {
  /* A multi-line comment
  nested in a function
  */
}
*/

//: [Next](@next)
