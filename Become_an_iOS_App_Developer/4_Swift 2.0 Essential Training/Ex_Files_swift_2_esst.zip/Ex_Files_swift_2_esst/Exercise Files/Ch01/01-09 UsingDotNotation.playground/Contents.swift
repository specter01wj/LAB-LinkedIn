//: ## Using Dot Notation

var foo = Foo()
var bar = Bar()
var bas = Bas()


