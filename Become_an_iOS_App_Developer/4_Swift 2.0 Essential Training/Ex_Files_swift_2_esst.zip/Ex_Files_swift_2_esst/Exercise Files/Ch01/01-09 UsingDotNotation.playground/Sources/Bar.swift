/// Has **`bas`** property equal to instance of **`Bas`**
public struct Bar {
  public var bas = Bas()
  public init() { }
}