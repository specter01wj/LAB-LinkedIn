/// Has **`bar`** property equal to instance of **`Bar`**
public struct Foo {
  public var bar = Bar()
  public init() { }
}
