//: ## Understanding Mutability

var helloString = "Hello, playground"

helloString = "Hello, world!"
