//: ## Defining Strings

var helloString = "Hello, playground"


