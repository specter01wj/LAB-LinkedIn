//: ## Defining Strings

var helloString: String = "Hello, playground"

let 💥 = "KER-SPLOINK!"

let `class` = "Geometry"
