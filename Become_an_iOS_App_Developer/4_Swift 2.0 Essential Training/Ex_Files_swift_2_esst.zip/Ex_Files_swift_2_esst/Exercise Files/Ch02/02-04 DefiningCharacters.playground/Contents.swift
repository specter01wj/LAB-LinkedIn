//: ## Defining Characters

let aCharacter = "a"

let bCharacter = "b"


