//: ## Defining Characters

let aCharacter: Character = "a"

let bCharacter = "b" as Character

let uWithUmlaut: Character = "\u{75}\u{308}"

let combinedUWithUmlaut: Character = "\u{FC}"
