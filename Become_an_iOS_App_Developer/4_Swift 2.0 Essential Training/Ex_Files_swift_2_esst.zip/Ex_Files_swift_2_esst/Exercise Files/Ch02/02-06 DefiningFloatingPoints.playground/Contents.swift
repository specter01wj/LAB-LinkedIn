/*:
## Defining Floating-Points
* `Float`: ~ 6 decimal place precision
* `Double`: ~ 15 decimal place precision
*/

let aDouble = 1.23

let aFloat = 1.23

let anInteger = 5


