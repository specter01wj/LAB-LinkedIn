//: ## Defining Booleans

let learningSwiftIsFun = true

let gettingARootCanalIsFun = false


