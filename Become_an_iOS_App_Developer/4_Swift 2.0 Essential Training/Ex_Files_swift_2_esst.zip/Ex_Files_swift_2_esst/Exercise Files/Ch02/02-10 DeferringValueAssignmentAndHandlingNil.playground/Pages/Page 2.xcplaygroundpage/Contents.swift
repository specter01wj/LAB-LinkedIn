//: [Previous](@previous)

//: ### Optionals

var maybeAString: String



var mostLikelyAnInt: Int



