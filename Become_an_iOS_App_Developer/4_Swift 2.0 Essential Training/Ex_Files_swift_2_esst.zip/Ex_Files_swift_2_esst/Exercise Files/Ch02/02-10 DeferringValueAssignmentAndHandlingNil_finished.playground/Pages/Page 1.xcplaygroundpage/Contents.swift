//: ## Deferring Value Assignment & Handling `nil`

//: ### Deferring Value Assignment

var aphorism: String
aphorism = "Do or do not. There is no try."

var one, two, three: Int
one = 1
two = 2
three = 3

let constantString: String

constantString = "Don't wish. Do."

//: [Next](@next)
