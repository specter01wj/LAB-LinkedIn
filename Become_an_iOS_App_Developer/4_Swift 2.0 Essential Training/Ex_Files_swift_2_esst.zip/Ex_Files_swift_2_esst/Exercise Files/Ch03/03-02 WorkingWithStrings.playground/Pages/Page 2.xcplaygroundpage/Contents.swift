//: [Previous](@previous)

//: ### Inspecting

let quote: String = "In the end, we only regret the chances we didn't take."

 

let string1 = "\u{61}\u{301}\u{20DD}"
let string2 = "\u{E1}\u{20DD}"

string1 == string2



//: [Next](@next)
