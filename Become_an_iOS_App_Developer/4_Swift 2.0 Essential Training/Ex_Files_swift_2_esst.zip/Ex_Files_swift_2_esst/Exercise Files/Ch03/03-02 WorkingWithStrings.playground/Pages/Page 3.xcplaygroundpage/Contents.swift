//: [Previous](@previous)

//: ### Modifying

var quote: String = "In the end, we only regret the chances we didn't take."



let replacementString = "it's not the years in your life that count. It's the life in your years. -- Abraham Lincoln"



//: [Next](@next)
