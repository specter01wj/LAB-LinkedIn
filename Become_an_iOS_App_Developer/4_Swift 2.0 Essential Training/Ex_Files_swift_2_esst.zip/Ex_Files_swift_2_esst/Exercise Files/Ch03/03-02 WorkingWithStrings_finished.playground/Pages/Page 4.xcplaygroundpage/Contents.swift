//: [Previous](@previous)

/*:
### Escape characters
* `\n` - new line (`\r` works, too)
* `\t` - tab
* `\` - escape `\` and `"`
* `\0` - null character
*/

print("\"Whatever you are, be a good one.\"\n\t\t\t-- Abraham Lincoln")

print("\0".isEmpty)

