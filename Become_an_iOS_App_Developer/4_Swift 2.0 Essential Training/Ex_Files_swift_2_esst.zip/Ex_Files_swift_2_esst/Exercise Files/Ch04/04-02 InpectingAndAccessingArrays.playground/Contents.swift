//: ## Inpecting & Accessing Arrays

var threeStooges = ["Moe", "Larry", "Curly"]


