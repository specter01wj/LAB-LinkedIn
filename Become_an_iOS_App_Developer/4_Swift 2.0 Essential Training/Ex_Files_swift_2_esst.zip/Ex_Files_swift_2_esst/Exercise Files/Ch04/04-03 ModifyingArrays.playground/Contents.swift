//: ## Modifying Arrays

var turnstileCounts = Array(count: 20, repeatedValue: 0)

var threeStooges = ["Moe", "Larry", "Curly"]


