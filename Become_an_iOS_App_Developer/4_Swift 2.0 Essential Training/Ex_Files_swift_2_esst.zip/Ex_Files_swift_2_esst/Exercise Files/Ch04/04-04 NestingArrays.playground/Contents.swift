//: ## Nesting Arrays

var threeStooges = ["Moe", "Larry", "Curly"]

var famousGroupsOfThree = [
  threeStooges,
  ["Huey", "Dewey", "Louie"],
  ["Athos", "Porthos", "Aramis"],
  ["Jack", "Chrissy", "Jane"]
]


