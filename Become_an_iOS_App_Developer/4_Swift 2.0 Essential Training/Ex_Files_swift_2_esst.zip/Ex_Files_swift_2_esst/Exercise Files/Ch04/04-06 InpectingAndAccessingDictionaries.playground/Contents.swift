//: ## Inpecting & Accessing Dictionaries

var stockPrices = ["AAPL": 110.37, "GOOG": 606.25, "MSFT": 43.5]

var ages = Dictionary<String, Int>()

stockPrices.count

ages.isEmpty


