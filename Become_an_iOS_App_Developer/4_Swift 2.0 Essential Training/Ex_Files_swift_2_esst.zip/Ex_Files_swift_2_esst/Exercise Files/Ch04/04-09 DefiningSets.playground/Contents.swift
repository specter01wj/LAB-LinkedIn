//: ## Defining Sets



var students: Set = ["Charlotte", "Laura", "Kayleigh", "Kayla", "Boz", "Jake"]


