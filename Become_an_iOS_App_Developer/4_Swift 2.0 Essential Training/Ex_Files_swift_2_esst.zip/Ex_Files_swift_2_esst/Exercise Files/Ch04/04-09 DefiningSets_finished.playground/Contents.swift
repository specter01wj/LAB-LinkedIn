//: ## Defining Sets

var teachers = Set<String>()

var staff: Set<String> = []

var students: Set = ["Charlotte", "Laura", "Kayleigh", "Kayla", "Boz", "Jake", "Charlotte"]

print(students)
