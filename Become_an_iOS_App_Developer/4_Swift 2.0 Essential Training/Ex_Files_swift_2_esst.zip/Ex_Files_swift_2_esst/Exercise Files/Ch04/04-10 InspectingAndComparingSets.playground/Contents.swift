//: ## Inspecting & Comparing Sets

var teachers = Set<String>()

var students: Set = ["Charlotte", "Laura", "Kayleigh", "Kayla", "Boz", "Jake"]



var schoolBusStudents: Set = ["Kayleigh", "Kayla", "Boz"]


