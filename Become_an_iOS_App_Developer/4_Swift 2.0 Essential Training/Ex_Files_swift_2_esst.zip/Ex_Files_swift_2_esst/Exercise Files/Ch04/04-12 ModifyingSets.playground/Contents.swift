//: ## Modifying Sets

let campAttendees: Set = ["Charlotte", "Laura", "Lilli", "Carlee", "Nathan"]

var students: Set = ["Charlotte", "Laura", "Kayleigh", "Kayla", "Boz", "Jake"]


