//: ## Nesting Sets

let stringSet1: Set = ["a", "b", "c"]

let stringSet2: Set = ["d", "e", "f"]

let integerSet: Set = [1, 2, 3]


