//: ## Accessing, Decomposing & Nesting Tuples

let httpStatus200 = (200, "OK")

var playerScores: ([Int], firstName: String, lastName: String?) = ([134_000, 128_500, 156_250], firstName: "Scott", lastName: "Gardner")


