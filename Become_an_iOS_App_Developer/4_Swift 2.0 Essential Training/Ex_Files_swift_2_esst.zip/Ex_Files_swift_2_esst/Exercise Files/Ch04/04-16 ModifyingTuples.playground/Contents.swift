//: ## Modifying Tuples

var anotherScore = (100, (firstName: "Scott", lastName: "Gardner"))


