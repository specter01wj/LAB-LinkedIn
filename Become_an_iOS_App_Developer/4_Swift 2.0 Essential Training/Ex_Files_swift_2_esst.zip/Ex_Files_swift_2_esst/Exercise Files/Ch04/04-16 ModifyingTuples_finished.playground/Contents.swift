//: ## Modifying Tuples

var anotherScore = (100, (firstName: "Scott", lastName: "Gardner"))

anotherScore.0 = 98

anotherScore.1.firstName = "Lori"
