//: [Previous](@previous)

//: ### Overflow

var a: UInt8 = UInt8.max



var b: Int8 = Int8.min



var c: UInt8 = 200



//: [Next](@next)

