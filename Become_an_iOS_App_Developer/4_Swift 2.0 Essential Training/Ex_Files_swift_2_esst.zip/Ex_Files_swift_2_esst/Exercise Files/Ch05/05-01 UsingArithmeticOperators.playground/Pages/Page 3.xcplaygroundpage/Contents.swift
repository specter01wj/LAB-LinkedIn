//: [Previous](@previous)

//: ### Strings

var hello = "Hello, "
let world = "world!"



let name = "Jaime"
let season = "Fall"

print("Hello, \(name)!" + "\n" + "Are you enjoying the \(season)?")

//: [Next](@next)
