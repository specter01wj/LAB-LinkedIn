//: [Previous](@previous)

//: ### Overflow

var a: UInt8 = UInt8.max
//a += 1

a &+ 1

var b: Int8 = Int8.min
b &- 1

var c: UInt8 = 200
c = c &* 2
55 + 1 + 144

//: [Next](@next)
