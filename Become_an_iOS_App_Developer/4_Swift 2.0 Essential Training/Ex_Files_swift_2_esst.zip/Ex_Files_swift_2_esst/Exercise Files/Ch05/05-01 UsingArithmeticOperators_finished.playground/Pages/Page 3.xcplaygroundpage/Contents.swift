//: [Previous](@previous)

//: ### Strings

var hello = "Hello, "
let world = "world!"

let greeting = hello + world
hello
world

hello += "viewer!"
hello

let name = "Jaime"
let season = "Fall"

print("Hello, \(name)!" + "\n" + "Are you enjoying the \(season)?")

//: [Next](@next)
