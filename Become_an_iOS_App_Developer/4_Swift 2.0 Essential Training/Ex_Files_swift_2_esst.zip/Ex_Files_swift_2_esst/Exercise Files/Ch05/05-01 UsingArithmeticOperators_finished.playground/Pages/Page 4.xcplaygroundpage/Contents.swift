//: [Previous](@previous)

//: ### Arrays

var apples = ["McIntosh", "Red Delicious"]
apples += ["Granny Smith"]

let oranges = ["Navel", "Valencia", "Moro"]

let mixApplesAndOranges = (apples + oranges).sort()
apples
oranges

