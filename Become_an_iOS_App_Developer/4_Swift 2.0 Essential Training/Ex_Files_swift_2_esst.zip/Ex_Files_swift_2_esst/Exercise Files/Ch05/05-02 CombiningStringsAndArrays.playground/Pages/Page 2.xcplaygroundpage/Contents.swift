//: [Previous](@previous)

//: ### Arrays

var apples = ["McIntosh", "Red Delicious"]



let oranges = ["Navel", "Valencia", "Moro"]



