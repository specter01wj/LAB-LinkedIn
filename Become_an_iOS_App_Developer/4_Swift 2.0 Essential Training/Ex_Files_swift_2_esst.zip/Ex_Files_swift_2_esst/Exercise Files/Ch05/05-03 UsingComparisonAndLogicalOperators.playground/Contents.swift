//: ## Using Comparison & Logical Operators

let a = 4
let b = 2
var c = a // Passed by copy

let x = SomeClass()
let y = SomeClass()
let z = x // Passed by reference

x.title
