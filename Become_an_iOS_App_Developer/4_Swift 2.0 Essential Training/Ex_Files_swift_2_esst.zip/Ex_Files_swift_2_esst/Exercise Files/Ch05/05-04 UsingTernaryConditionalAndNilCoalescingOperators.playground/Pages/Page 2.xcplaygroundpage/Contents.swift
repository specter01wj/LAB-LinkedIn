//: [Previous](@previous)

//: ### Nil Coalescing

let defaultSize = "M"

var selectedSize: String?

let orderSize = selectedSize ?? defaultSize
