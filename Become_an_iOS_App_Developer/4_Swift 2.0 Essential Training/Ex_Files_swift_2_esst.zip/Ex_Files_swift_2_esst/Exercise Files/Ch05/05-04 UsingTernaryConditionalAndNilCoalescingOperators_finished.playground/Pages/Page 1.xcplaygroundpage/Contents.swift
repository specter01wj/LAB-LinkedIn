//: ## Using Ternary Conditional & Nil Coalescing Operators

//: ### Ternary Conditional

let name = "Charlotte"



let birthYear = 2005



//: [Next](@next)
