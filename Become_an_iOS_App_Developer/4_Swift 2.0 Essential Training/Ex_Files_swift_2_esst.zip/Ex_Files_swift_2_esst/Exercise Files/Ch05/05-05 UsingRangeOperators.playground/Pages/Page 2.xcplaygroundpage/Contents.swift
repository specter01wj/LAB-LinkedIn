//: [Previous](@previous)

//: ### Strings

var palindrome = "A man a plan a canal Panama"

palindrome.isPalindrome()



let replacement = "a cat a ham a yak a yam a hat a canal"



//: [Next](@next)
