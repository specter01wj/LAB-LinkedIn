//: [Previous](@previous)

//: ### Arrays

var fibonacciNumbers = [1, 3, 6, 10, 15, 21] // Not!



let replacement = [1, 2, 3, 5, 8, 13]


