//: ## Using Range Operators

let rangeA = 0..<10

let rangeB = 0...10

0...10 == 0..<11
//: [Next](@next)
