//: ## Understanding Operator Precedence & Associativity

let a: Double = 1 + 2 * 3 / 4 % 5

let b: Double = (1 + (((2 * 3) / 4) % 5))
