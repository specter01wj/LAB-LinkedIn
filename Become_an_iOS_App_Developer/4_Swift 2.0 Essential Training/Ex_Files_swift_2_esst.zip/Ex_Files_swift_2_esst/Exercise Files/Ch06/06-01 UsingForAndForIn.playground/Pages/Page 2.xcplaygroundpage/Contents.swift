//: [Previous](@previous)

//: ### For-In



let people = ["man": "👦", "woman": "👩", "girl": "👧", "boy": "👦"]



let letters: Set = ["a", "b", "c"]



let phrases = ["A couple", "A few or some", "Several or many"]



let numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9]


