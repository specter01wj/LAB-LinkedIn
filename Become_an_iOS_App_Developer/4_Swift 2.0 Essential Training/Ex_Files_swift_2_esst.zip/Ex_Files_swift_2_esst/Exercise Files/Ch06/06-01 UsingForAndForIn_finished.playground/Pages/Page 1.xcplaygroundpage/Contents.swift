//: ## Using For & For-In

//: ### For

for var i = 1; i < 1024; i *= 2 {
  print(i)
}

//: [Next](@next)
