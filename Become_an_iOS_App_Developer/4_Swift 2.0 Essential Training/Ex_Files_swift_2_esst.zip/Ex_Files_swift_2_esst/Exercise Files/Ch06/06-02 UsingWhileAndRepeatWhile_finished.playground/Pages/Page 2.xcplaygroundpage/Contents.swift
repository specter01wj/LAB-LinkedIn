//: [Previous](@previous)

//: ### Repeat-While

import Foundation

repeat {
  print(".", terminator: "")
} while arc4random_uniform(6) + 1 != 1 && arc4random_uniform(6) + 1 != 1

print("Snake eyes!")


