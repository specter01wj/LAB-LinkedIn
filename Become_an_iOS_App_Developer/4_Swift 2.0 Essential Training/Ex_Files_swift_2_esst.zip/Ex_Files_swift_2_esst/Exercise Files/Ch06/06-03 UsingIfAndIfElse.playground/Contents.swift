//: ## Using If & If-Else

import Foundation

let testScore = arc4random_uniform(50) + 50



print("Your grade: ", terminator: "")


