//: ## Optional Binding

var firstName: String? = "Betty"



var lastName: String? = "Gardner"


