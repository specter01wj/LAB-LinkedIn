//: ## Using Guard

import Foundation

let twentyOnesBirthday = NSDate().dateByAddingTimeInterval(-31_536_000 * 21)

let peopleInLine = ["Joey": joeysBirthday, "Brenda": brendasBirthday, "Chris": chrisBirthday, "Oliver": oliversBirthday]



func updateSignForLifeguardOnDuty(lifeguardOnDuty: String?) {
  
}


