import Foundation

public let joeysBirthday = NSDate().dateByAddingTimeInterval(-31_536_001 * 21)

public let brendasBirthday = NSDate().dateByAddingTimeInterval(-31_536_001 * 19)

public let chrisBirthday = NSDate().dateByAddingTimeInterval(-31_536_001 * 23)

public let oliversBirthday = NSDate().dateByAddingTimeInterval(-31_536_001 * 22)
