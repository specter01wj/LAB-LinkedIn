//: ## Using Switch

let die1 = [1, 2, 3, 4, 5, 6].randomItem()
let die2 = [1, 2, 3, 4, 5, 6].randomItem()


