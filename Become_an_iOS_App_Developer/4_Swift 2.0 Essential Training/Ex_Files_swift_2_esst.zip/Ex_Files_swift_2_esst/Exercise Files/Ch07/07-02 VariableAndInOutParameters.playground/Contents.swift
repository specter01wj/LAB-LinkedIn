//: ## Variable & In-Out Parameters

var studentsScore = 76.0
let meanScore = 88.0


