//: ## Reference Type Parameters

let person = Person(firstName: "Bob")



func reverseFirstNameOfPerson(person: Person) {
  
}


//: [Next](@next)
