//: [Previous](@previous)

//: ### Function Parameters

func addTwoIntegers(a: Int, _ b: Int) -> Int {
  return a + b
}



