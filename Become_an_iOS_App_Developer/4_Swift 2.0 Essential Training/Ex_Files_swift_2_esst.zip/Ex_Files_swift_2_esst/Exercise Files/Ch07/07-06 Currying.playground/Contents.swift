//: ## Currying

import Foundation


