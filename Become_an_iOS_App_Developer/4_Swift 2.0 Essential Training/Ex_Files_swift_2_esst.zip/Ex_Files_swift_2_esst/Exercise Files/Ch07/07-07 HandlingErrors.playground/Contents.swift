//: ## Handling Errors

import Foundation

let encounteredErrorA = simulatedErrorDidOccur()
let encounteredErrorB = simulatedErrorDidOccur()


