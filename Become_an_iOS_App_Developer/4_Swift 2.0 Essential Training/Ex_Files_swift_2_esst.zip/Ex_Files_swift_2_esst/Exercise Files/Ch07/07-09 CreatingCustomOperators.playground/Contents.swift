/*:
## Creating Custom Operators
### .., /, =, -, +, !, *, %, <, >, &, |, ^, ?, or ~, or certain Unicode characters
[See documentation](http://bit.ly/swiftlexicalstructure)
*/

import UIKit



let pointA = CGPoint(x: 5, y: 5)

let pointB = CGPoint(x: 5, y: 10)


