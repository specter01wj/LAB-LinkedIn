//: ## Working with Closures

import Foundation

var names = ["Scott", "Lori", "Charlotte", "Betty", "Gracie", "Sophie", "Stella", "Isabella", "Lilith", "Darby"]



let phrase = "It doesn't matter in what order the letters of a word appear as long as the first and last characters are in the right place the rest can be a total mess and you can probably still read it"


