//: ## Working with Singletons


