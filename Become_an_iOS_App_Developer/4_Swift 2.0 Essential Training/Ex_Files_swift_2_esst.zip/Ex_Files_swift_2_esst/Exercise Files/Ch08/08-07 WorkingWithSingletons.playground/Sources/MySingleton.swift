/// Access shared instance via `sharedInstance` type property, e.g., `MySingleton.sharedInstance`
public class MySingleton {
  
  
  
}