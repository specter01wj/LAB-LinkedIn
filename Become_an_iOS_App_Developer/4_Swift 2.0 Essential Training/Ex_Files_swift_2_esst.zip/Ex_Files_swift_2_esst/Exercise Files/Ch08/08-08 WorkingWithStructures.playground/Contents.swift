//: ## Working With Structures

import Foundation

let aString: String?

protocol Protocol1 { }
protocol Protocol2 { }

struct MyStruct {
  // Properties, initializers, methods, subscripts
}

struct ProtocolAdoptingStruct: Protocol1, Protocol2 {
  // Properties, initializers, methods, subscripts
}


