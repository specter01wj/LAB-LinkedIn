//: ## Creating Mutating Structures

struct Counter {
  
  var total = 0
  
  func increment() {
    
  }
  
  func reset() {
    
  }
  
}


