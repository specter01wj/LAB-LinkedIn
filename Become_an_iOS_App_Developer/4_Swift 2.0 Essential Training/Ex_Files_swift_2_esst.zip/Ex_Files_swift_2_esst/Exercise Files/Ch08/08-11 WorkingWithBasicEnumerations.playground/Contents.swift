//: ## Working With Basic Enumerations

import Foundation

enum Direction {
  
  case Up
  case Down
  case Left
  case Right
  
}



let spade = "♠️"
let heart = "♥️"
let diamond = "♦️"
let club = "♣️"


