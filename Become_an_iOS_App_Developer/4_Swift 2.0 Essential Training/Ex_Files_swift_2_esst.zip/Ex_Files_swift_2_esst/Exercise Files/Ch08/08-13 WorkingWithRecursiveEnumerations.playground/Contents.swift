//: ## Working With Recursive Enumerations

enum Employee {
  
  case None
  case Some(name: String, title: String)
  
  static func printOrgChartFromEmployee(employee: Employee) {
    
  }
  
}


