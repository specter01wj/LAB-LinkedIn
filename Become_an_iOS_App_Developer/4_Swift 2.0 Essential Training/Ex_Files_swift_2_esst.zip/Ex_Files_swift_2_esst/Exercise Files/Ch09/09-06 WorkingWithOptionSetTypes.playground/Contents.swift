//: ## Working With `OptionSetType`

//enum Option: Int {
//  
//  case A = 1 << 0 // 1
//  case B = 1 << 1 // 2
//  case C = 1 << 2 // 4
//  
//}


