//: ## Subclassing

class Vehicle {
  
  let passengerCapacity: Int
  
  init(passengerCapacity: Int) {
    self.passengerCapacity = passengerCapacity
  }
  
}
