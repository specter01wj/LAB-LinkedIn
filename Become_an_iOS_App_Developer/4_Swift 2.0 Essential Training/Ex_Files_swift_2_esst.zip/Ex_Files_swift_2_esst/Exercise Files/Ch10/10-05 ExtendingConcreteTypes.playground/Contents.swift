//: ## Extending Concrete Types

let quickBrownFox: String = "The quick brown fox jumped over the lazy dog"

quickBrownFox.characters.count


