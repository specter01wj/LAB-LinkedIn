//
//  CustomFramework.h
//  CustomFramework
//
//  Created by Scott Gardner on 9/19/15.
//  Copyright © 2015 Scott Gardner. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CustomFramework.
FOUNDATION_EXPORT double CustomFrameworkVersionNumber;

//! Project version string for CustomFramework.
FOUNDATION_EXPORT const unsigned char CustomFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CustomFramework/PublicHeader.h>


