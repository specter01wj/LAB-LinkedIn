private let value1 = 1

public let value2 = "Two"

public class CustomFrameworkClass {
  
  let title = "CustomFrameworkClass"
  
}

public struct CustomFrameworkStruct {
    
  public init() { }
  
}

extension CustomFrameworkStruct {
  
  var title: String {
    return "CustomFrameworkStruct"
  }
  
}

public typealias CFStruct = CustomFrameworkStruct

public enum CustomFrameworkEnum {
  
  case One
  case Two(CFStruct)
  
}
