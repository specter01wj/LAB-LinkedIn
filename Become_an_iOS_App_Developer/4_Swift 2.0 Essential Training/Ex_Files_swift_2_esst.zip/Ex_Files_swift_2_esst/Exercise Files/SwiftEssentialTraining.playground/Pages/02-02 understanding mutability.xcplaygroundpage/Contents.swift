//: [Table of Contents](table%20of%20contents)

//: [Previous](@previous)

//: # Chapter 2 - Variables & Constants

//: ## Understanding Mutability

var helloString = "Hello, playground"

helloString = "Hello, world!"

//: [Next](@next)
