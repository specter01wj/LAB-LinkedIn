//: [Table of Contents](table%20of%20contents)

//: [Previous](@previous)

//: ## Defining Strings

var helloString: String = "Hello, playground"

let 💥 = "KER-SPLOINK!"

let `class` = "Geometry"

//: [Next](@next)
