//: [Table of Contents](table%20of%20contents)

//: [Previous](@previous)

//: ## Defining Booleans

let learningSwiftIsFun = true

let gettingARootCanalIsFun: Bool = false

//: [Next](@next)
