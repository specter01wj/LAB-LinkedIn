//: [Table of Contents](table%20of%20contents)

//: [Previous](@previous)

//: ## Defining Type Aliases

typealias IPOctet = UInt8

let minOctetValue = IPOctet.min

let maxOctetValue = IPOctet.max

//: [Next](@next)
