//: [Table of Contents](table%20of%20contents)

//: [Previous](@previous)

//: ## Defining Dictionaries

var stockPrices = ["AAPL": 110.37, "GOOG": 606.25, "MSFT": 43.5]

var birthYears: [String: Int] = [:]

var raceResults = Dictionary<Int, String>()

let tourDeFranceResults: [Int: String]
tourDeFranceResults = [
  1: "Chris Froome",
  2: "Nairo Quintana",
  3: "Alejandro Valverde"
]

//: [Next](@next)
