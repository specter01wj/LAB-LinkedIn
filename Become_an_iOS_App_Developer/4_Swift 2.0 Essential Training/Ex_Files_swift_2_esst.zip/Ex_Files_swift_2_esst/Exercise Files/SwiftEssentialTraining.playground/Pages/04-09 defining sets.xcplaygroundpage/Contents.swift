//: [Table of Contents](table%20of%20contents)

//: [Previous](@previous)

//: ## Defining Sets

var teachers = Set<String>()

var staff: Set<String> = []

var students: Set = ["Charlotte", "Laura", "Kayleigh", "Kayla", "Boz", "Jake", "Charlotte"]

print(students)

//: [Next](@next)
