//: [Table of Contents](table%20of%20contents)

//: [Previous](@previous)

//: ## Nesting Sets

let stringSet1: Set = ["a", "b", "c"]

let stringSet2: Set = ["d", "e", "f"]

let integerSet: Set = [1, 2, 3]

let setOfStringSets: Set = [stringSet1, stringSet2]

//: [Next](@next)
