//: [Table of Contents](table%20of%20contents)

//: [Previous](@previous)

//: ## Understanding Operator Precedence & Associativity

let a: Double = 1 + 2 * 3 / 4 % 5

let b: Double = (1 + (((2 * 3) / 4) % 5))

//: [Next](@next)
