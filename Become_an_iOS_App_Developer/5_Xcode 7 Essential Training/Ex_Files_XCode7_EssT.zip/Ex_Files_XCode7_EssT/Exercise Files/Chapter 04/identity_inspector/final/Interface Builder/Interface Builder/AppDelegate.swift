//
//  AppDelegate.swift
//  Interface Builder
//
//  Created by LDC on 9/21/15.
//  Copyright © 2015 LDC. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {

    @IBOutlet weak var window: NSWindow!
    @IBOutlet weak var myLabel: NSTextField!
    var name:String = "{not set}"

    func applicationDidFinishLaunching(aNotification: NSNotification) {
        // Insert code here to initialize your application
        myLabel.stringValue = name
    }

    func applicationWillTerminate(aNotification: NSNotification) {
        // Insert code here to tear down your application
    }


}

