//
//  main.cpp
//  Compiler
//
//  Created by LDC on 9/24/15.
//  Copyright © 2015 LDC. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, Todd!\n";
    return 0;
}
