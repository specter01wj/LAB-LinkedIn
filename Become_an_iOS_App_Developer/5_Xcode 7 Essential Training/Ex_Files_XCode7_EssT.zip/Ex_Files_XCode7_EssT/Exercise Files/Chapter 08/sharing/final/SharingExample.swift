//
//  SharingExample.swift
//  
//
//  Created by LDC on 9/30/15.
//
//

import UIKit

var exampleVar:String = "Hi everyone!"

class SharingExample: NSObject {

}
