//
//  ViewController.m
//  Analyze
//
//  Created by LDC on 9/30/15.
//  Copyright © 2015 LDC. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    int x;
    BOOL y = false;
    if (y) {
        x = y;
    }
    NSLog(@"x is %i", x);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
