//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var num = 20

for (var i = 0; i < 10; i += 1) {
    num += 10 * i
}