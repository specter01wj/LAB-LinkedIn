//constant

let a = 3

//fails with constants
//a += 3

//variable
var b = 5
b += 3