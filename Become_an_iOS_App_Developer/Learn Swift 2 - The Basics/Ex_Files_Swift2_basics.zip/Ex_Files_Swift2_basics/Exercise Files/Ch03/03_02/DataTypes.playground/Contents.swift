var a = "text example"

//fails
//a = 5