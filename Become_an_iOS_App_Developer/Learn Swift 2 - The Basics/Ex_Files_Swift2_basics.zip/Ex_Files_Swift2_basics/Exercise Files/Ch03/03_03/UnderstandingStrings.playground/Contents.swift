let myString = "part1" + "part2"

var str = "string"
str += " more"

let constant1 = "test1"
let constant2 = "test2"

let resultConstant = constant1 + constant2

var numDays = 5

//There are __ days until the weekend

let toPrint = "There are \(numDays) days until the weekend"

let stringNumDays = "5"

let alternateToPrint = "There are " + stringNumDays + " days until the weekend"

let numString = "\(numDays)"

let numString2 = String(numDays)

let finalStringToPrint = "There are " + numString2 + " days until the weekend"

