var myArray : [Int] = [3,5,7]

myArray[0]

myArray[2]

myArray[0] = 10

//fails
//myArray[100] = 10

var myArray2 : [Int] = Array()

myArray2.append(5)

var complexArray : [Any] = Array()

complexArray.append(3)
complexArray.append("String value")

myArray.count

myArray.removeAtIndex(0)

myArray