var myDictionary = ["apple":"red","banana":"yellow"]

var myDictionary2 : [String:Int] = Dictionary()

myDictionary2["key1"] = 4
myDictionary2["key2"] = 15

myDictionary2["key1"]

var myDictionary3 : [String:Any] = Dictionary()

myDictionary3["key1"] = 3
myDictionary3["key2"] = "test string"

myDictionary3
