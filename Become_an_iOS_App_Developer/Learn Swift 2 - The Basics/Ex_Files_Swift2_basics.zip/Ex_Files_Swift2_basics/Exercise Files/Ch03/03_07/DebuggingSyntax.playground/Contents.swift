var a : MadeUpType

struct MyNewStruct {
    var a = 4
    
    func editMyValue() {
        a += 4
    }
}

var myCounter = 1.0
myCounter += 1.5

