
let numberA = 1
let numberB = 2
let numberC = 3

let stringA = "String 1"
let stringB = "String 2"
let stringC = "String 3"

let numberArray = [numberA,numberB,numberC]

let stringArray = [stringA,stringB,stringC]

var combinedDictionary : [String:Int] = Dictionary()

combinedDictionary[stringA] = numberA
combinedDictionary[stringB] = numberB
combinedDictionary[stringC] = numberC

combinedDictionary

