var a = (3 + 5) * 2

var b = 5

b += 10

b *= 4

var intVar = 4
var doubleVar = 3.5

var result = Double(intVar) + doubleVar

var newNumber : Double = 4

result = newNumber + doubleVar

