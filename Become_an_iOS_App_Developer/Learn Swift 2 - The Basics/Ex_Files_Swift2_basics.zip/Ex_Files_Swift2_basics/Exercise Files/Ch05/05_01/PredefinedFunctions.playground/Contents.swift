print("hello")

var myArray = [3,5,7]
myArray.append(10)

let returnValue = abs(-5)

let maxNumber = max(100,200,-8)

print("1","2","3", separator:"--")

