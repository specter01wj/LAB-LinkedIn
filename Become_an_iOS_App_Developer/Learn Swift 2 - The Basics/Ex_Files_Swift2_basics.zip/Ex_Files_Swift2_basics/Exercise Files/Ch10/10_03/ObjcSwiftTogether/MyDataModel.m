//
//  MyDataModel.m
//  ObjcSwiftTogether
//
//  Created by J Nastos on 12/16/15.
//  Copyright © 2015 J Nastos. All rights reserved.
//

#import "MyDataModel.h"

@implementation MyDataModel

- (int) intPropertySquared {
    return self.intProperty * self.intProperty;
}

@end
