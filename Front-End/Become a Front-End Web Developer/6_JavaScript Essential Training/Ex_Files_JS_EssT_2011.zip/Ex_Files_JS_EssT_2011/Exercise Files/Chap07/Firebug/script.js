

window.onload = function() {
	var pageTitle = document.getElementById("pageID");
	pageTitle.innerHTML = "This title was replaced by JavaScript";
};

