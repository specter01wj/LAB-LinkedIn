// Simple prototype example

function Player(n) {
    this.name = n;
}


var fred =  new Player("Fred");














