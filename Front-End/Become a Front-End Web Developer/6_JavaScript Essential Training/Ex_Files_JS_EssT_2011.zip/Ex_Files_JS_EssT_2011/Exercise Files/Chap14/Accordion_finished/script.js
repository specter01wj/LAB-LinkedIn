window.onload = function () {
   $("#accordion").accordion();
};