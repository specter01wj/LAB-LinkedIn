(function(){

	// script goes here

})();