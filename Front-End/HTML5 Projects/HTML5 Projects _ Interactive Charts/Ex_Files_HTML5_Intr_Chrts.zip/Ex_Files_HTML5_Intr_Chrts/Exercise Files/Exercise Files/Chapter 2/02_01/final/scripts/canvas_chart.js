// Load source images

// Initialize stage

// Update anchors if group moved

// Create anchor groups

// Set image sources

// Load images and initialize stage when done

