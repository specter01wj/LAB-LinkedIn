// Load source images

// Initialize stage
function initStage() {
	var stage = new Kinetic.Stage({
		container: 'container',
		width: 600,
		height: 400
	});
	
} // End initStage()

// Update anchors if group moved

// Create anchor groups

// Set image sources

// Load images and initialize stage when done

