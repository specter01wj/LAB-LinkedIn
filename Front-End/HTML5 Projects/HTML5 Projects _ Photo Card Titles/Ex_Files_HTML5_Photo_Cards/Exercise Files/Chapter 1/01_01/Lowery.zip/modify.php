<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>TPA: Trans Planet Airlines - Modify Photo</title>
<link href="styles/main.css" rel="stylesheet" type="text/css">
<script src="scripts/modernizr-1.6.min.js"></script>
<script src="http://code.jquery.com/jquery-1.8.2.min.js"></script>
<script src="scripts/kinetic-v4.40.js"></script>
<script src="scripts/canvas_resize.js"></script>
<script src="scripts/binaryajax.js"></script>
<script src="scripts/imageinfo.js"></script>
<script type="text/javascript" src="jscolor/jscolor.js"></script>
<script type="text/javascript" src="scripts/html5slider.js"></script>
<script type="text/javascript">
      window.onload = function() {
		var theBg = localStorage.getItem("theChoice");
        var theFile = localStorage.getItem('uploadedFile');
		theFile = "uploads/" + theFile;
		theBg = "images/" + theBg;
		var sources = {
          myBg: theBg,
          myImage: theFile
        };

		ImageInfo.loadInfo(theFile, getDimensions);
        loadImages(sources, initStage);

		function getDimensions() {
			var theWidth = ImageInfo.getField(theFile, "width")/2;
			var theHeight = ImageInfo.getField(theFile, "height")/2;
			localStorage.setItem("imageWidth",theWidth);
			localStorage.setItem("imageHeight",theHeight);
			}
		
		$("#saveImage").click(function(e) {
			e.preventDefault();
			$theInfo = "<h1>Step 4:  Right click on image and choose <span class='highlight'>Save Image</span></h1>";
			$("#steps").html($theInfo);
		});
      };
	  
</script>

</head>

<body id="modifyPage">
<div id="outerWrapper">
  <div id="header"><img src="images/logo.png" width="410" height="181" alt="TPA: Trans Planet Airlines" /><br>
  <img src="images/tpa_name.gif" width="373" height="37" alt="Trans Planet Airlines">
  </div>
  <div id="nav">
  <h1>Create Your Own Space Souvenir!</h1>
    <ul>
      <li><a href="index.php">START</a></li>
      <li><a href="beam-up.php">UPLOAD</a></li>
      <li><a href="modify.php">MODIFY</a></li>
      <li><a href="caption.php">CAPTION</a></li>
      <li><a href=# id="saveImage">SAVE</a></li>
    </ul>
  </div>
<div id="content">
<div id="steps">
  <h1>Step 3: Reshape and drag your image into position</h1>
  </div>
<div id="container"></div>
      <button id="save">
        Save as image
      </button>
<form>
  <p>Text:
  <input id="textBox" placeholder="Your Title" value="" />
   </p>
  <p> Text Font:
  <select id="textFont">
    <option value="serif">serif</option>
    <option value="sans-serif">sans-serif</option>
    <option value="cursive">cursive</option>
    <option value="fantasy">fantasy</option>
    <option value="monospace">monospace</option>
  </select>
    </p>
  <p> Text Size:
      <input type="range" id="textSize"
       min="0"
       max="200"
       step="1"
       value="50"/> 
    </p>
  <p> Fill Type :
  <select id="fillType">
    <option value="colorFill">Color Fill</option>
    <option value="linearGradient">Linear Gradient</option>
    <option value="radialGradient">Radial Gradient</option>
  </select>
    </p>
  <p> Text Color:
      <input class="color" id="textFillColor" value="FF0000"/> 
    </p>
  <p> Text Color 2:
      <input class="color" id="textFillColor2" value ="000000"/> 
    </p>
  <p> Alpha :
    <input type="range" id="textAlpha"
       min="0.0"
       max="1.0"
       step="0.01"
       value="1.0"/>
  </p>
  <p> Shadow X:
    <input type="range" id="shadowX"
       min="-100"
       max="100"
       step="1"
       value="1"/>
    </p>
  <p> Shadow Y:
    <input type="range" id="shadowY"
       min="-100"
       max="100"
       step="1"
       value="1"/>
    </p>
  <p> Shadow Blur:

      <input type="range" id="shadowBlur"
       min="1"
       max="100"
       step="1"
       value="1" /> 
    </p>
  <p> Shadow Color:

      <input class="color" id="shadowColor" value="707070"/>
  </p>
  <p>
    <input type="button" id="createImageData" value="Create Image Data">
    <br>
    
    <br>
    <textarea id="imageDataDisplay" rows=10 cols=30></textarea>
  </p>
 </form>
</div>

<div id="footer">
  <p>Copyright &copy; 2054 Trans Planet Airlines, LLC. All rights reserved</p>
</div></div>
</body>
</html>
