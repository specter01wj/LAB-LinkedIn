      function update(group, activeAnchor) {
        var topLeft = group.get(".topLeft")[0];
        var topRight = group.get(".topRight")[0];
        var bottomRight = group.get(".bottomRight")[0];
        var bottomLeft = group.get(".bottomLeft")[0];
        var image = group.get(".image")[0];

        // update anchor positions
        switch (activeAnchor.getName()) {
          case "topLeft":
            topRight.attrs.y = activeAnchor.attrs.y;
            bottomLeft.attrs.x = activeAnchor.attrs.x;
            break;
          case "topRight":
            topLeft.attrs.y = activeAnchor.attrs.y;
            bottomRight.attrs.x = activeAnchor.attrs.x;
            break;
          case "bottomRight":
            bottomLeft.attrs.y = activeAnchor.attrs.y;
            topRight.attrs.x = activeAnchor.attrs.x;
            break;
          case "bottomLeft":
            bottomRight.attrs.y = activeAnchor.attrs.y;
            topLeft.attrs.x = activeAnchor.attrs.x;
            break;
        }

        image.setPosition(topLeft.attrs.x, topLeft.attrs.y);

        var width = topRight.attrs.x - topLeft.attrs.x;
        var height = bottomLeft.attrs.y - topLeft.attrs.y;
        if(width && height) {
          image.setSize(width, height);
        }
      }
      function addAnchor(group, x, y, name) {
        var stage = group.getStage();
        var layer = group.getLayer();

        var anchor = new Kinetic.Circle({
          x: x,
          y: y,
          strokeWidth: 0,
          radius: 10,
          name: name,
          draggable: true
        });

        anchor.on("dragmove", function() {
          update(group, this);
          layer.draw();
        });
        anchor.on("mousedown touchstart", function() {
          group.setDraggable(false);
          this.moveToTop();
        });
        anchor.on("dragend", function() {
          group.setDraggable(true);
          layer.draw();
        });
        // add hover styling
        anchor.on("mouseover", function() {
          var layer = this.getLayer();
          document.body.style.cursor = "pointer";
          this.setStrokeWidth(4);
		  layer.draw();
        });
        anchor.on("mouseout", function() {
          var layer = this.getLayer();
          document.body.style.cursor = "default";
          this.setStrokeWidth(0);
          layer.draw();
        });

        group.add(anchor);
      }
      function loadImages(sources, callback) {
        var images = {};
        var loadedImages = 0;
        var numImages = 0;
        for(var src in sources) {
          numImages++;
        }
        for(var src in sources) {
          images[src] = new Image();
          images[src].onload = function() {
            if(++loadedImages >= numImages) {
              callback(images);
            }
          };
          images[src].src = sources[src];
        }
      }
      function initStage(images) {
        var stage = new Kinetic.Stage({
          container: "container",
		  width: 640,
          height: 476
        });
		
        var theW = parseInt(localStorage.getItem("imageWidth"));
        var theH = parseInt(localStorage.getItem("imageHeight"));

        var bgGroup = new Kinetic.Group({
          x: 0,
          y: 0,
          draggable: false
        });
		
        var fgGroup = new Kinetic.Group({
          x: 100,
          y: 100,
          draggable: true
        });
		
        var layer = new Kinetic.Layer();
		
		var textLayer = new Kinetic.Layer({
				draggable: true
			});
		var textContext = textLayer.getContext();
		var theMessage = "Your Title";
		var textFillColor ="#ff0000";
		var fontSize = '50';
		var fontFace = 'serif';
		var fillType = "colorFill";
		var textFillColor2 ="#000000";

/*
 	var theTitle = 'Your Title!';
     var theText = new Kinetic.Text({
        x: stage.getWidth() / 2,
        y: stage.getHeight() / 2,
        text: theTitle,
        fontSize: 30,
        fontFamily: 'Calibri',
		draggable: true,
        fill: 'green'
      });
      theText.setOffset({
        x: theText.getWidth() / 2,
      });

*/

        layer.add(bgGroup);
        layer.add(fgGroup);
//      	textLayer.add(theText);
        stage.add(layer);
		stage.add(textLayer);
		
        // Background image
        var bgImg = new Kinetic.Image({
          x: 0,
          y: 0,
          image: images.myBg,
          width: 640,
          height: 476,
          name: "image"
        });

        bgGroup.add(bgImg);

        // Uploaded Image
        var myNewImg = new Kinetic.Image({
          x: 0,
          y: 0,
          image: images.myImage,
		  width: theW,
		  height: theH,
          name: "image"
        });

        fgGroup.add(myNewImg);
        addAnchor(fgGroup, 0, 0, "topLeft");
        addAnchor(fgGroup, theW, 0, "topRight");
        addAnchor(fgGroup, theW, theH, "bottomRight");
        addAnchor(fgGroup, 0, theH, "bottomLeft");

        fgGroup.on("dragstart", function() {
          this.moveToTop();
        });


        stage.draw();

	var formElement = document.getElementById("textBox");
	formElement.addEventListener("change", textBoxChanged, false);	

	formElement = document.getElementById("textFillColor");
	formElement.addEventListener("change", textFillColorChanged, false);	
	
	formElement = document.getElementById("textSize");
	formElement.addEventListener("change", textSizeChanged, false);	
	
	formElement = document.getElementById("textFont");
	formElement.addEventListener("change", textFontChanged, false);	
	
	formElement = document.getElementById("textFillColor2");
	formElement.addEventListener("change", textFillColor2Changed, false);	
	
	formElement = document.getElementById("fillType");
	formElement.addEventListener("change", fillTypeChanged, false);	
	
	var xPos = stage.getWidth() / 2;
	var yPos = stage.getHeight() /2;

// Main text drawing routine
	function drawText() {
		textLayer.clear();
		textContext.font = fontSize + 'px ' + fontFace;
 	 	textContext.fillStyle = textFillColor;
		textWidth = textContext.measureText(theMessage).width;
		textOffset = textWidth / 2;
//		textContext.fillText(theMessage,xPos-textOffset,yPos);

		var tempColor;
		if (fillType == "colorFill") {
			tempColor = textFillColor;
		} else if (fillType == "linearGradient") {
			var gradient = textContext.createLinearGradient(xPos-textOffset, yPos, textWidth, yPos);
			gradient.addColorStop(0,textFillColor);
			gradient.addColorStop(.6,textFillColor2);
			tempColor = gradient;
		} else if (fillType == "radialGradient") {
			var gradient = textContext.createRadialGradient(xPos, yPos, fontSize, xPos+textWidth, yPos, 1);
			gradient.addColorStop(0,textFillColor);
			gradient.addColorStop(.6,textFillColor2);
			tempColor = gradient;
		} else {
			tempColor = textFillColor;
		}
		textContext.fillStyle = tempColor;
		textContext.fillText(theMessage,xPos-textOffset,yPos);


	}

// Text event functions
	function textBoxChanged(e) {
		target =  e.target;
		theMessage = target.value;
		drawText();
	}

	function textFillColorChanged(e) {
		target =  e.target;
		textFillColor = "#" + target.value;
		drawText();
	}

	function textSizeChanged(e) {
		var target =  e.target;
		fontSize = target.value;
		drawText();
	}
	
	function textFontChanged(e) {
		var target =  e.target;
		fontFace =  target.value;
		drawText();
	}

	function textFillColor2Changed(e) {
		var target =  e.target;
		textFillColor2 = "#" + target.value;
		drawText();
	}
	
	function fillTypeChanged(e) {
		var target =  e.target;
		fillType =  target.value;
		drawText();
	}
	
// Save canvas to image
        document.getElementById("save").addEventListener("click", function() {
          stage.toDataURL({
            callback: function(dataUrl) {
              window.open(dataUrl);
            }
          });
        }, false);

      }

