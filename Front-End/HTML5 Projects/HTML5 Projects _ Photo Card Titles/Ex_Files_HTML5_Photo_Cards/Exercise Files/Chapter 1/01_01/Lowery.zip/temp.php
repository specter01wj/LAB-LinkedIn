<!DOCTYPE HTML>
<html>
  <head>
    <style>
      body {
        margin: 0px;
        padding: 0px;
      }
    </style>
  </head>
  <body>
    <div id="container"></div>
    <script src="http://www.html5canvastutorials.com/libraries/kinetic-v4.3.0-beta2.js"></script>
    <script>
      var stage = new Kinetic.Stage({
        container: 'container',
        width: 578,
        height: 220
      });
      var layer = new Kinetic.Layer();

      var simpleText = new Kinetic.Text({
        x: stage.getWidth() / 2,
        y: 25,
        text: 'Simple Text',
        fontSize: 30,
        fontFamily: 'Calibri',
        fill: 'red'
      });

      // to align text in the middle of the screen, we can set the
      // shape offset to the center of the text shape after instantiating it
      simpleText.setOffset({
        x: simpleText.getWidth() / 2
      });

      // since this text is inside of a defined area, we can center it using
      // align: 'center'

      // add the shapes to the layer
      layer.add(simpleText);
      stage.add(layer);

    </script>
  </body>
</html>