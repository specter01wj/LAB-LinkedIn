var Note = React.createClass({
    render: function() {
        
});

React.render(<Note>Hello World</Note>, 
    document.getElementById('react-container'));