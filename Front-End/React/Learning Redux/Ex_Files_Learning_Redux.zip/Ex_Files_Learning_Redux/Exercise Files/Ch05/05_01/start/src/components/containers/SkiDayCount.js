import SkiDayCount from '../ui/SkiDayCount'

export default () =>
	<SkiDayCount total={100} powder={25} backcountry={10} />
