export const Whoops404 = () => 
	<div>
		<h1>Whoops, route not found</h1>
	</div>