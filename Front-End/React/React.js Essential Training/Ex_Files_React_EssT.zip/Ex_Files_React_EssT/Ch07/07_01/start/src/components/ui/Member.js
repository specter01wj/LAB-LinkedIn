import FaShield from 'react-icons/lib/fa/shield' 
import { Component } from 'react'

class Member extends Component {

render() {
	
    return (
        <div className="member">

        //
        // TODO: Create Member Component
        //

        </div>
    )
}
}

export default Member