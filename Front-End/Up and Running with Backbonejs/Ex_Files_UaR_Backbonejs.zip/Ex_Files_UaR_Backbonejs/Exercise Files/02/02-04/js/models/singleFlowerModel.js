// Namespace our app
var app = app || {};

app.Flower = Backbone.Model.extend({

});