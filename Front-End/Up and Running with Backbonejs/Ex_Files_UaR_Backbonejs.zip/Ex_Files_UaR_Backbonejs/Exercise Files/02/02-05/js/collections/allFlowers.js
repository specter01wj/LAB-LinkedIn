// Namespace our flowerApp
var app = app || {};

app.EuropeanFlower = Backbone.Collection.extend({

  model: app.singleFlower

});