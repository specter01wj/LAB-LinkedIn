// Namespace our app
var app = app || {};

app.singleFlower = Backbone.Model.extend({

  defaults: {
    color: "pink",
    img: "images/placeholder.jpg"
  }

});