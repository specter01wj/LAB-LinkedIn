#
# Example file for working with classes
# (For Python 3.x, be sure to use the ExampleSnippets3.txt file)

      
def main():
  
if __name__ == "__main__":
  main()
