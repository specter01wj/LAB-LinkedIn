#
# Example file for working with functions
# (For Python 3.x, be sure to use the ExampleSnippets3.txt file)

