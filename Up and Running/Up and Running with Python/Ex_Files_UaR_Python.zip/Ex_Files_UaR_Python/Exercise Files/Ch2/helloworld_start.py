#
# Example file for HelloWorld
# (For Python 3.x, be sure to use the ExampleSnippets3.txt file)

