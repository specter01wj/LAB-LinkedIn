# 
# Example file for parsing and processing XML
# (For Python 3.x, be sure to use the ExampleSnippets3.txt file)

    
if __name__ == "__main__":
  main();

