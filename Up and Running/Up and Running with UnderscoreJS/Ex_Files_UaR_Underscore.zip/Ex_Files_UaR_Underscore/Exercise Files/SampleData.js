var students = [
	{
		"firstname": "Woody",
		"lastname" : "Johnson",
		"school" : "Thoreau",
		"grade" : 12,
		"midterm_score": 75,
		"final_score": 85
	},
	{
		"firstname" : "Jerry",
		"lastname" : "Jones",
		"school" : "Thoreau",
		"grade" : 10,
		"midterm_score": 50,
		"final_score": 65		
	},
	{
		"firstname" : "Bill",
		"lastname" : "Parcells",
		"school" : "Franklin",
		"grade" : 12,
		"midterm_score": 82,
		"final_score": 91		
	},
	{
		"firstname" : "Rex",
		"lastname" : "Ryan",
		"school" : "Franklin",
		"grade" : 11,
		"midterm_score": 60,
		"final_score": 67		
	},
	{
		"firstname" : "Norv",
		"lastname" : "Turner",
		"school" : "Thoreau",
		"grade" : 11,
		"midterm_score": 58,
		"final_score": 71		
	},
	{
		"firstname" : "Pete",
		"lastname" : "Carroll",
		"school" : "Franklin",
		"grade" : 9,
		"midterm_score": 79,
		"final_score": 93		
	},
	{
		"firstname" : "Tony",
		"lastname" : "Dungee",
		"school" : "Thoreau",
		"grade" : 9,
		"midterm_score": 88,
		"final_score": 100		
	},
	{
		"firstname" : "John",
		"lastname" : "Harbaugh",
		"school" : "Franklin",
		"grade" : 12,
		"midterm_score": 74,
		"final_score": 81		
	},
	{
		"firstname" : "Tom",
		"lastname" : "Coughlin",
		"school" : "Thoreau",
		"grade" : 10,
		"midterm_score": 62,
		"final_score": 80		
	},
	{
		"firstname" : "Bruce",
		"lastname" : "Arians",
		"school" : "Thoreau",
		"grade" : 9,
		"midterm_score": 78,
		"final_score": 86		
	},
	{
		"firstname" : "Mike",
		"lastname" : "Smith",
		"school" : "Franklin",
		"grade" : 11,
		"midterm_score": 70,
		"final_score": 75		
	},
	{
		"firstname" : "Doug",
		"lastname" : "Marrone",
		"school" : "Franklin",
		"grade" : 10,
		"midterm_score": 90,
		"final_score": 80		
	},
	{
		"firstname" : "Ron",
		"lastname" : "Rivera",
		"school" : "Thoreau",
		"grade" : 12,
		"midterm_score": 60,
		"final_score": 76		
	},
	{
		"firstname" : "Marc",
		"lastname" : "Trestman",
		"school" : "Franklin",
		"grade" : 12,
		"midterm_score": 78,
		"final_score": 91		
	},
	{
		"firstname" : "Marvin",
		"lastname" : "Lewis",
		"school" : "Thoreau",
		"grade" : 10,
		"midterm_score": 55,
		"final_score": 65		
	},
	{
		"firstname" : "Jason",
		"lastname" : "Garrett",
		"school" : "Thoreau",
		"grade" : 11,
		"midterm_score": 60,
		"final_score": 68		
	},
	{
		"firstname" : "John",
		"lastname" : "Fox",
		"school" : "Franklin",
		"grade" : 9,
		"midterm_score": 82,
		"final_score": 87		
	},
	{
		"firstname" : "Gary",
		"lastname" : "Kubiak",
		"school" : "Franklin",
		"grade" : 9,
		"midterm_score": 92,
		"final_score": 95		
	},
	{
		"firstname" : "Chuck",
		"lastname" : "Pagano",
		"school" : "Thoreau",
		"grade" : 10,
		"midterm_score": 70,
		"final_score": 72		
	},
	{
		"firstname" : "Andy",
		"lastname" : "Reid",
		"school" : "Thoreau",
		"grade" : 12,
		"midterm_score": 84,
		"final_score": 87		
	}
	
];
